---
name: zip-upload-regression
description: A ZIP installation test skill.
---
Read references/guide.md.
